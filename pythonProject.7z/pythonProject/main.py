# import math
#
# a = int(input())
# b = int(input())
# if a < 1:
#     x = a * (b ** 3)
# else:
#     x = b * (b + 1)
# y = (math.log(1 + x ** 2) + math.cos(x + 1)) ** math.e ** a * x
# print(y)


x = input("Введите слово:")
y =  input('Введите слово:')
z = input('Введите слово:')
if type(x) is int or float:
    if float(x) > float(y):
        min = float(y)
    else:
        min = x
    if float(x) > float(y) and float(z):
        max =float( x)
    if float(y) > float(x) and float(z):
        max = y
    if float(z) > float(x) and float(y):
        max = float(z)
    m = (max / min) + 5
    print(m)
else:
    print('ошибка')

if type(y) is int or float:
    if x > y:
        min = y
    else:
        min = x
    if x > y and z:
        max = x
    if y > x and z:
        max = y
    if z > x and y:
        max = z
    m = (max / min) + 5
    print(m)
else:
    print('ошибка')

if type(z) is int or float:
    if x > y:
        min = y
    else:
        min = x
    if x > y and z:
        max = x
    if y > x and z:
        max = y
    if z > x and y:
        max = z
    m = (max / min) + 5
    print(m)
else:
    print('ошибка')

